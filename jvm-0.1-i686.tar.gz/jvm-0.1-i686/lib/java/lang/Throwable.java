
package java.lang;

public class Throwable {
	public Throwable() { }
	public Throwable(String M) { }
	public Throwable(String M, Throwable C) { }
	public Throwable(String M, Throwable C, boolean E, boolean S) { }
	public Throwable(Throwable T) { }
}
