
package jvm;

public final class Runtime {
	public static native Object clone(Object O);
	public static native void finalize(Object O);
}
